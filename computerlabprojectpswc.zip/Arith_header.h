#include"Header.h"
void menu();
void calculator_operations();
void addition();
void subtraction();
void multiplication();
void division();
void modulus();
void power();
void factorial();
void absolute();
void ratio();
void percent();
void INV();
void root();
void expression();
int precedence(char a,char b);
int operate(int a,int b,char oper);
void postfixConvert();
