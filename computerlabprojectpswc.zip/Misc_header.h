#include"Header.h"
void menu();
void calculator_operations();
void BMI();
void quadratic();
typedef struct complex
{
float real;
float imag;
}COMP;
void Complex();
COMP add(COMP*,COMP*);
COMP sub(COMP*,COMP*);
void G_L();