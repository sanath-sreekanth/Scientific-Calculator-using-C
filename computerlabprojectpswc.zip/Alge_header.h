#include"Header.h"
void menu();
void calculator_operations();
void input(int m;int n;int a[m][n],int m,int n);
void display(int m;int n;int a[m][n],int m,int n);
void matrix_add();
void matrix_sub();
void matrix_mul();
void matrix();
void log_exp();
void AP();
void GP();
void AGP();
void seq_sum_ser();
void SE();
int fact(int n);
void P_and_C();