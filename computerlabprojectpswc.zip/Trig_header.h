#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include"Header.h"
void trig();
void menu();
void calculator_operations();
void itrig();
void trigh();
