#include"Calc_header.h"

void menu()
{
    printf("\n--------------------------------------------------------------------------------------\n");
    printf("---------------------------WELCOME TO THE SCIENTIFIC CALCULATOR---------------------------- \n");
    printf("---------------------------------------------------------------------------------------\n");
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    printf("----------------------------MENU----------------------------\n");
    printf("Enter (1) FOR ARITHMETIC CALCULATOR\n");
    printf("Enter (2) FOR ALGEBRAIC CALCULATOR\n");
    printf("Enter (3) FOR CONVERSION CALCULATOR\n");
    printf("Enter (4) FOR TRIGONOMETRIC CALCULATOR\n");
    printf("Enter (5) MISCELLANEOUS OPERATIONS\n");
    printf("Enter (0) TO EXIT\n");
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
}